<?php
// $Id: uc_order.tpl.php,v 1.1.2.1 2010/07/16 15:45:09 islandusurper Exp $

/**
 * @file
 * This file is a dummy template.
 *
 * It serves as a reminder to theme authors that they must have a
 * uc_order.tpl.php file in their theme if they want to override the other
 * order templates.
 */
